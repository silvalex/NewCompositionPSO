package pso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents the nodes and edges of a graph.
 *
 * @author sawczualex
 */
public class Graph<T> {
	public Map<T, GraphEdge> edgeMap = new HashMap<T, GraphEdge>();
	public Map<T, GraphNode> nodeMap = new HashMap<T, GraphNode>();
}
