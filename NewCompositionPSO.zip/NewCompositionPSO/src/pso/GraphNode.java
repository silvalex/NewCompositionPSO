package pso;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Represents a node in the web service
 * composition graph.
 *
 * @author sawczualex
 */
public class GraphNode {
	public Service s;
	public int id;
	public List<GraphEdge> from = new ArrayList<GraphEdge>();
	public List<GraphEdge> to = new ArrayList<GraphEdge>();
	public Set<String> input = new HashSet<String>();
	public Set<String> output = new HashSet<String>();

	public GraphNode(Service s) {
		this.s = s;
		id = s.id;
	}

	public GraphNode(GraphNode other) {
		s = other.s;
		id = other.id;
		from = new ArrayList<GraphEdge>(other.from);
		to = new ArrayList<GraphEdge>(other.to);
		input = new HashSet<String>(other.input);
		output = new HashSet<String>(other.output);
	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public String toString(){
		return s.toString();
	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object other) {
		boolean result = false;
		if (other != null && other instanceof GraphNode)
			result = ((GraphNode)other).id == id;
		return result;
	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		return id;
	}

}
