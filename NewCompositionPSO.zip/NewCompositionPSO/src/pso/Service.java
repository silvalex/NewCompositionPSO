package pso;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

/**
 * Represents a web service, including numerical values
 * that represent Quality of Service scores, inputs and outputs.
 *
 * @author sawczualex
 */
public class Service {
	public static double minTime = Double.MAX_VALUE;
	public static double maxTime = Double.MIN_VALUE;
	public static double minCost = Double.MAX_VALUE;
	public static double maxCost = Double.MIN_VALUE;

	public int id;
	public String name;
	public double time;
	public double cost;
	public double availability;
	public double reliability;

	public Set<String> input = new HashSet<String>();
	public Set<String> output = new HashSet<String>();

	public Service(int id, String name, double time, double cost, double availability, double reliability, String[] input, String[] output) {
		this.id = id;
		this.name = name;
		this.availability = availability;
		this.reliability = reliability;
		this.time = time;
		this.cost = cost;
		// Convert arrays to sets
		Collections.addAll(this.input, input);
		Collections.addAll(this.output, output);
	}

	public Service(int id, Scanner s) {
		this.id = id;
		name = s.next();
		Collections.addAll(input, s.next().split(","));
		Collections.addAll(output, s.next().split(","));
		time = s.nextDouble();
		cost = s.nextDouble();
		availability = s.nextDouble();
		reliability = s.nextDouble();
		// Throw the other two away;
		s.nextDouble();
		s.nextDouble();

		// Update global minimums and maximums
		updateMinMax(time, cost);
	}

	/**
	 * Resets static fields.
	 */
	public static void reset() {
		minTime = Double.MAX_VALUE;
		maxTime = Double.MIN_VALUE;
		minCost = Double.MAX_VALUE;
		maxCost = Double.MIN_VALUE;
	}

	/**
	 * Normalises the attributes according to minimum
	 * and maximum values in the service, placing them in
	 * the [0,1] range.
	 */
	public void normalizeAttributes() {
		availability /= 100;
		reliability /= 100;
//		time = (time - minTime)/(maxTime - minTime); // XXX
//		cost = (cost - minCost)/(maxCost - minCost);
	}

	/**
	 * Updates global minimum and maximum attribute values for
	 * web services in the dataset based on the arguments provided.
	 *
	 * @param time
	 * @param cost
	 */
	public static void updateMinMax(double time, double cost) {
		if (time < minTime)
			minTime = time;
		if (time > maxTime)
			maxTime = time;

		if (cost < minCost)
			minCost = cost;
		if (cost > maxCost)
			maxCost = cost;
	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public String toString() {
		return String.valueOf(id);
	}

	/**
	 * Returns String representing service as
	 * it was read from file (pads discarded
	 * values with 0).
	 *
	 * @return representation
	 */
	public String toFileString() {
		String inputBlock = input.toString().replaceAll("[\\[\\] ]", "");
		String outputBlock = output.toString().replaceAll("[\\[\\] ]", "");
		String result = String.format("%s %s %s %f %f %f %f 0 0", name, inputBlock, outputBlock, time, cost, availability, reliability);
		return result;
	}

	/**
	 * Returns String representing service as
	 * it was read from file (does not pad discarded values).
	 *
	 * @return representation
	 */
	public String toFileStringNoPadding() {
		String inputBlock = input.toString().replaceAll("[\\[\\] ]", "");
		String outputBlock = output.toString().replaceAll("[\\[\\] ]", "");
		String result = String.format("%s %s %s %f %f %f %f", name, inputBlock, outputBlock, time, cost, availability, reliability);
		return result;
	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object other) {
		boolean result = false;
		if (other != null && other instanceof Service)
			result = ((Service)other).id == id;
		return result;
	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		return id;
	}
}
