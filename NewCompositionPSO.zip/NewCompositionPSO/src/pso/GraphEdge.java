package pso;

import java.util.HashSet;
import java.util.Set;

/**
 * Represents an edge in the web service
 * composition graph.
 *
 * @author sawczualex
 */
public class GraphEdge implements Comparable<GraphEdge>{

	public GraphNode from;
	public GraphNode to;
	public Set<String> overlap = new HashSet<String>();
	public int id;
	public double score;

	public GraphEdge(Set<String> overlap, int id) {
		this.overlap = overlap;
		this.id = id;
	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public String toString() {
		return String.format("%s --> %s", from.toString(), to.toString());
	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public int compareTo(GraphEdge o) {
		if (o == null)
			throw new NullPointerException("Comparing GraphEdge to null object!");
		else {
			double diff = score - o.score;
			if (diff == 0.0)
				return 0;
			else if (diff < 0.0)
				return 1;
			else
				return -1;
		}
	}
}
