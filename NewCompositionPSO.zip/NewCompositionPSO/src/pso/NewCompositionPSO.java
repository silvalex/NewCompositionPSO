package pso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import org.apache.log4j.SimpleLayout;
import org.perf4j.LogParser;
import org.perf4j.LoggingStopWatch;
import org.perf4j.StopWatch;
import org.perf4j.helpers.GroupedTimingStatisticsFormatter;
import org.perf4j.helpers.GroupedTimingStatisticsTextFormatter;
import org.perf4j.log4j.Log4JStopWatch;

/**
 * NEW VERSION
 *
 * This class contains the application entry point for the PSO algorithm created
 * for performing QoS-aware Web service composition.
 *
 * @author sawczualex
 */
public class NewCompositionPSO {
	// Logging
	private Logger _logger;
	private static FileAppender _appender;
	private static String _logFileName;
	private static String _statLogFileName;
	private static final Level SETUP = new CustomLevel("SETUP");
	private static final Level RUN = new CustomLevel("RUN");
	private static final Level POSTRUN = new CustomLevel("POSTRUN");
	private static final Level DETAILS = new CustomLevel("DETAILS");

	// PSO settings
	private List<Particle> _swarm = new ArrayList<Particle>();
	public static final int MAX_NUM_ITERATIONS = 100;
	public static final int NUM_PARTICLES = 30;
	// Max. generations global best can remain stagnant before stopping PSO
	public static final int MAX_STAGNANT = 100;
	public static int numDimensions;
	public static final float C1 = 1;
	public static final float C2 = 1;
	public static final float W = 1;

	// Fitness function weights
	public static final double W1 = 0.25;
	public static final double W2 = 0.25;
	public static final double W3 = 0.25;
	public static final double W4 = 0.25;
	// public static final double W1 = 0.2;//0.2
	// public static final double W2 = 0.3;//0.3
	// public static final double W3 = 0.2;//0.2
	// public static final double W4 = 0.3;//0.3
	// public static final double W5 = 1;//0.5
	// public static final double W6 = 1;

	// Service settings
	public static List<Service> serviceList = new ArrayList<Service>();
	public static final int NULL_IDX = 0;
	public static final int START_IDX = 1;
	public static final int END_IDX = 2;
	public static int numServices;

	// Graph variables
	private Graph<Integer> _masterGraph;
	private Map<String, List<Service>> _outputMap = new HashMap<String, List<Service>>();
	private int _longestPathLength = 0;
	private double _totalTime = 0.0;
	private double _totalCost = 0.0;

	// Run settings
	private static String _filename = "bigCompositionTest40-h.txt";
	public static String[] INPUT = { "input0" };
	public static String[] OUTPUT = { "output39", " output38", " output37", " output40" };
//	private static String _filename = "dataset5.txt";
//	public static String[] INPUT = {"From", "To", "DepartDate", "ReturnDate"};
//	public static String[] OUTPUT = {"ArrivalDate", "Reservation", "BusTicket", "Map"};

	public static final int NUM_RUNS = 50;
	private Random _random;
	private static final int SEED_COEFFICIENT = 333;

	/**
	 * Application's entry point.
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		new NewCompositionPSO(null, null, null, null, null);
	}

	/**
	 * Sets up logging for this session..
	 */
	public void setupLogging() {
		try {
			_logger = Logger.getLogger(NewCompositionPSO.class);
			SimpleLayout layout = new SimpleLayout();
			_appender = new FileAppender(layout, _logFileName + ".txt", false);
			_logger.addAppender(_appender);
			_logger.setLevel(Level.ALL);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Creates a functionally correct workflow, and runs the PSO to discover the
	 * optimal services to be used in it.
	 */
	public NewCompositionPSO(String logName, String statLogName,
			String dataset, String[] input, String[] output) {
		if (dataset != null)
			_filename = dataset;
		if (input != null)
			INPUT = input;
		if (output != null)
			OUTPUT = output;
		// String dateTime
		if (logName != null && statLogName != null) {
			_logFileName = logName;
			_statLogFileName = statLogName;
		}
		// Create your own names
		else {
			String timeDate = new SimpleDateFormat("_dd-MM-yyyy_HH-mm-ss")
					.format(Calendar.getInstance().getTime());
			_logFileName = "pso" + timeDate;
			_statLogFileName = "psoStats" + timeDate;
		}
		setupLogging();

		StopWatch setupWatch = new Log4JStopWatch("SetupTime", _logger, SETUP);
		_populateServiceList();
		// Reset static fields
		Service.reset();
		Particle.reset();

		_populateOutputMapNormalize(serviceList);
		Set<Service> services = new HashSet<Service>(
				_getRelevantServices(serviceList));
		_masterGraph = _createMasterGraph(services);
		setupWatch.stop();

		// Log setup values
		_logger.log(SETUP, "Filename: " + _filename);
		_logger.log(SETUP, "NumServices: " + numServices);
		_logger.log(SETUP, "TaskInput: " + Arrays.toString(INPUT));
		_logger.log(SETUP, "TaskOutput: " + Arrays.toString(OUTPUT));
		_logger.log(SETUP, "NumRuns: " + NUM_RUNS);
		_logger.log(SETUP, "NumParticles: " + NUM_PARTICLES);
		_logger.log(SETUP, "NumDimensions: " + numDimensions);
		_logger.log(SETUP, "MaxNumIterations: " + MAX_NUM_ITERATIONS);
		_logger.log(SETUP, "MaxStagnant: " + MAX_STAGNANT);
		_logger.log(SETUP, "SeedCoefficient: " + SEED_COEFFICIENT);
		_logger.log(SETUP, "pso_C1: " + C1);
		_logger.log(SETUP, "pso_C2: " + C2);
		_logger.log(SETUP, "pso_W: " + W);
		_logger.log(SETUP, "fitness_W1: " + W1);
		_logger.log(SETUP, "fitness_W2: " + W2);
		_logger.log(SETUP, "fitness_W3: " + W3);
		_logger.log(SETUP, "fitness_W4: " + W4);

		_logger.log(RUN, "Seed: " + SEED_COEFFICIENT);
		_random = new Random(SEED_COEFFICIENT);

		StopWatch runWatch;
		for (int i = 0; i < NUM_RUNS; i++) {
			System.out.println("RUN " + i);

			// Reset global fitness
			Particle.globalBestFitness = Double.NEGATIVE_INFINITY;

			_logger.log(RUN, "Run: " + i);

			runWatch = new Log4JStopWatch("RunTime", _logger, RUN);
			_runPSO();
			runWatch.stop();

			_logger.log(RUN, "GlobalBestFitness: " + Particle.globalBestFitness);
			_logger.log(
					RUN,
					"GlobalBestWorkflow: "
							+ _printWorkflow(Particle.globalBestWorkflow.edgeMap
									.values()));
			_logger.log(
					RUN,
					"GlobalBestDimensions: "
							+ Arrays.toString(Particle.globalBestDimensions));
		}

		 _logger.log(POSTRUN, "OverallGlobalBestFitness: "
		 + Particle.overallGlobalBestFitness);
		 _logger.log(
		 POSTRUN,
		 "OverallGlobalBestWorkflow: "
		 + _printWorkflow(Particle.overallGlobalBestWorkflow.edgeMap
		 .values()));
		 _logger.log(
		 POSTRUN,
		 "OverallGlobalBestDimensions: "
		 + Arrays.toString(Particle.overallGlobalBestDimensions));
		 _generateStatistics();
		 _logger.removeAppender(_appender);
		 _appender.close();
	}

	/**
	 * Generates a summarised file with statistics and info extracted from the
	 * corresponding pso log.
	 */
	public static void _generateStatistics() {
		try {
			// Setup info
			PrintStream stats = new PrintStream(new File(_statLogFileName
					+ ".txt"));

			Scanner scan = new Scanner(new File(_logFileName + ".txt"));
			while (scan.hasNext(SETUP.toString())) {
				// Append setup info
				stats.append(scan.nextLine() + "\n");
			}
			stats.append("\n");

			while (scan.hasNext(DETAILS.toString())
					|| scan.hasNext(RUN.toString())) {
				// Throw detailed info away
				scan.nextLine();
			}

			while (scan.hasNext()) {
				// Append post-run info
				stats.append(scan.nextLine() + "\n");
			}
			scan.close();
			stats.append("\n");

			// Perf4J info
			Reader reader = new FileReader(_logFileName + ".txt");
			LogParser parser = new LogParser(reader, stats, null, 10800000,
					true, new GroupedTimingStatisticsTextFormatter());
			parser.parseLog();
			stats.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Resets static fields.
	 */
//	 public static void reset() {
//	 Logger.getRootLogger().getLoggerRepository().resetConfiguration();
//	 setupLogging();
//	 if (_logger != null) {
//	 _logger.removeAllAppenders();
//	 _appender.close();
//	 SimpleLayout layout = new SimpleLayout();
//	 try {
//	 _appender = new FileAppender(layout,_logFileName+".txt",false);
//	 } catch (IOException e) {
//	 e.printStackTrace();
//	 }
//	 _logger.addAppender(_appender);
//	 }
//	 }

	/**
	 * Goes through the service list and retrieves only those services which
	 * could be part of the composition task requested by the user.
	 *
	 * @param serviceList
	 * @return relevant services
	 */
	private List<Service> _getRelevantServices(List<Service> serviceList) {
		// Copy service map values to retain original
		Collection<Service> services = new ArrayList<Service>(serviceList);

		Set<String> cSearch = new HashSet<String>(
				serviceList.get(START_IDX).input);
		List<Service> sList = new ArrayList<Service>();
		Set<Service> sFound = _discoverService(services, cSearch);
		while (!sFound.isEmpty()) {
			sList.addAll(sFound);
			services.removeAll(sFound);
			for (Service s : sFound) {
				cSearch.addAll(s.output);
				_totalCost += s.cost;
				_totalTime += s.time;
			}
			sFound.clear();
			sFound = _discoverService(services, cSearch);
		}
		if (cSearch.containsAll(serviceList.get(END_IDX).output)) {
			return sList;
		} else {
			String message = "It is impossible to perform a composition using the services and settings provided.";
			_logger.log(Level.ERROR, message);
			_logger.log(Level.ERROR, "Filename: " + _filename);
			_logger.log(Level.ERROR, "TaskInput: " + Arrays.toString(INPUT));
			_logger.log(Level.ERROR, "TaskOutput: " + Arrays.toString(OUTPUT));
			System.out.println(message);
			System.exit(0);
			return null;
		}
	}

	/**
	 * Conducts the particle swarm optimization.
	 */
	private void _runPSO() {
		// 1. Initialize the swarm
		_initializeRandomSwarm();

		int i = 0;
		int noChange = 0;
		Particle p;
		Graph<Integer> workflow;

		while (i < MAX_NUM_ITERATIONS && noChange < MAX_STAGNANT) {
			System.out.println("ITERATION " + i);

			// Go through all particles
			for (int j = 0; j < NUM_PARTICLES; j++) {
				System.out.println("PARTICLE " + j);
				p = _swarm.get(j);
				// 2. Evaluate fitness of particle
				workflow = _calculateFitness(p);
				// 3. If fitness of particle is better than Pbest, update the
				// Pbest
				p.updatePersonalBest();
				// 4. If fitness of Pbest is better than Gbest, update the Gbest
				if (p.bestFitness > Particle.globalBestFitness) {
					Particle.globalBestFitness = p.bestFitness;
					Particle.globalBestWorkflow = workflow;
					Particle.globalBestDimensions = Arrays.copyOf(
							p.bestDimensions, p.bestDimensions.length);

					if (Particle.globalBestFitness > Particle.overallGlobalBestFitness) {
						Particle.overallGlobalBestFitness = Particle.globalBestFitness;
						Particle.overallGlobalBestWorkflow = Particle.globalBestWorkflow;
						Particle.overallGlobalBestDimensions = Arrays.copyOf(
								Particle.globalBestDimensions,
								Particle.globalBestDimensions.length);
					}
					noChange = 0;

					_logger.log(RUN, String.format(
							"NewBestFitness- Iteration: %d Fitness: %f", i,
							Particle.globalBestFitness));
				}
				// 5. Update the velocity of particle
				_updateVelocity(p);
				// 6. Update the position of particle
				_updatePosition(p);
			}
			_logger.log(DETAILS, String
					.format("%d %f %s", i, Particle.globalBestFitness,
							_printWorkflow(Particle.globalBestWorkflow.edgeMap
									.values())));
			i++;
			noChange++;
		}

		_logger.log(RUN, "IterationsUsed: " + i);
	}

	/**
	 * Populate the service map with web service inputs, outputs and QoS values.
	 */
	private void _populateServiceList() {
		serviceList.clear();

		try {
			Scanner scan = new Scanner(new File(_filename));
			// Add default services
			serviceList.add(NULL_IDX, new Service(NULL_IDX, "NullService", 0,
					0, 1, 1, new String[] {}, new String[] {})); // Null service
			serviceList.add(START_IDX, new Service(START_IDX, "StartService",
					0, 0, 1, 1, INPUT, INPUT)); // Start service
			serviceList.add(END_IDX, new Service(END_IDX, "EndService", 0, 0,
					1, 1, OUTPUT, OUTPUT)); // End service

			int id = 3;
			while (scan.hasNext())
				serviceList.add(id, new Service(id++, scan));
			scan.close();
		} catch (FileNotFoundException e) {
			System.out.printf("Invalid filename argument: '%s'.", _filename);
			e.printStackTrace();
		}
		numServices = serviceList.size();
	}

	/**
	 * Populates the output map using the services provided as an argument and
	 * normalizes the attributes of each service.
	 *
	 * @param services
	 */
	private void _populateOutputMapNormalize(List<Service> services) {
		for (Service s : services) {
			if (s.id != START_IDX && s.id != END_IDX && s.id != NULL_IDX)
				s.normalizeAttributes();
			for (String outputVal : s.output) {
				if (_outputMap.containsKey(outputVal))
					_outputMap.get(outputVal).add(s);
				else {
					List<Service> list = new ArrayList<Service>();
					list.add(s);
					_outputMap.put(outputVal, list);
				}
			}
		}
	}

	/**
	 * For the services provided, creates a graph that connects all the possible
	 * input and output pairs between any of the two services.
	 *
	 * @param services
	 * @return graph of input-output matches
	 */
	private Graph<Integer> _createMasterGraph(Set<Service> services) {
		Graph<Integer> g = new Graph<Integer>();
		int edgeId = 0;
		Set<String> input;
		GraphNode inNode;
		List<Service> list;
		GraphNode outNode;
		Set<String> overlap;
		GraphEdge edge;
		for (Service s : services) {
			if (s.id != START_IDX) {
				input = s.input;
				inNode = _getGraphNode(s.id, g);
				for (String i : input) {
					list = _outputMap.get(i);
					if (list != null) {
						for (Service out : list) {
							if (services.contains(out) && s.id != out.id) {
								outNode = _getGraphNode(out.id, g);
								overlap = new HashSet<String>();
								overlap.add(i);
								edge = new GraphEdge(overlap, edgeId);
								edge.from = outNode;
								edge.to = inNode;
								inNode.from.add(edge);
								outNode.to.add(edge);
								g.edgeMap.put(edgeId++, edge);
							}
						}
					}
				}
			}
		}
		numDimensions = g.edgeMap.size();
		return g;
	}

	/**
	 * Initialises the swarm with random positions and velocities.
	 */
	private void _initializeRandomSwarm() {
		_swarm.clear();
		for (int i = 0; i < NUM_PARTICLES; i++) {
			_swarm.add(new Particle(_random));
		}
	}

	/**
	 * Discovers all services whose input can be fully satisfied by the search
	 * set.
	 *
	 * @param searchSet
	 * @return set of discovered services
	 */
	private Set<Service> _discoverService(Collection<Service> services,
			Set<String> searchSet) {
		Set<Service> found = new HashSet<Service>();
		for (Service s : services) {
			if (s.id != NULL_IDX && searchSet.containsAll(s.input)) {
				found.add(s);
			}
		}
		return found;
	}

	/**
	 * Returns a string version of the workflow.
	 */
	private String _printWorkflow(Collection<GraphEdge> workflowList) {
		StringBuilder b = new StringBuilder();
		for (GraphEdge e : workflowList) {
			b.append(String.format("%s --> %s ", e.from.s.name, e.to.s.name));
		}
		return b.toString();
	}

	/**
	 * Given a service ID, return its graph node. Note that this method will
	 * create a node for a service if one currently does not exist.
	 *
	 * @param id
	 * @return node
	 */
	private GraphNode _getGraphNode(int id, Graph<Integer> graph) {
		GraphNode node = graph.nodeMap.get(id);
		if (node == null) {
			node = new GraphNode(serviceList.get(id));
			graph.nodeMap.put(id, node);
		}
		return node;
	}

	/**
	 * Uses the Bellman-Ford algorithm with negative weights to find the longest
	 * path in an acyclic directed graph.
	 *
	 * @param g
	 * @return list of edges composing longest path
	 */
	private double _findLongestPath(Graph<Integer> g) {
		Map<Integer, Double> distance = new HashMap<Integer, Double>();
		Map<Integer, GraphNode> predecessor = new HashMap<Integer, GraphNode>();

		// Step 1: initialize graph
		for (GraphNode node : g.nodeMap.values()) {
			if (node.s.id == START_IDX)
				distance.put(node.s.id, 0.0);
			else
				distance.put(node.s.id, Double.POSITIVE_INFINITY);
		}

		// Step 2: relax edges repeatedly
		for (int i = 1; i < g.nodeMap.size(); i++) {
			for (GraphEdge e : g.edgeMap.values()) {
				if ((distance.get(e.from.s.id) - e.to.s.time) < distance
						.get(e.to.s.id)) {
					distance.put(e.to.s.id,
							(distance.get(e.from.s.id) - e.to.s.time));
					predecessor.put(e.to.s.id, e.from);
				}
			}
		}

		// Now retrieve total cost
		GraphNode pre = predecessor.get(END_IDX);
		double totalTime = 0.0;

		_longestPathLength = 0;
		while (pre != null) {
			_longestPathLength++;
			totalTime += pre.s.time;
			pre = predecessor.get(pre.s.id);
		}
		_longestPathLength -= 2;
		if (_longestPathLength == 0)
			_longestPathLength = 1;
		return totalTime;
	}

	/**
	 * Uses a modified greedy search algorithm to find a particular workflow in
	 * the master graph based on the scores provided in the dimension
	 * parameters. Each dimensions provides a score to an edge in the master
	 * graph. The edges with the highest scores are selected by the algorithm
	 * when building a particular workflow.
	 *
	 * @param dimensions
	 * @return workflow
	 */
	private Graph<Integer> _getWorkflow(float[] dimensions) {
		Graph<Integer> graph = new Graph<Integer>();
		int edgeIdx = 0;

		// Queue for services to be matched
		Queue<GraphNode> queue = new LinkedList<GraphNode>();
		GraphNode end = new GraphNode(_masterGraph.nodeMap.get(END_IDX));
		queue.add(end);

		// Set to record visits
		Set<Integer> visited = new HashSet<Integer>();

		Set<String> sInput;
		// While there are more services to connect

		GraphNode sConn;
		GraphNode nodeTo;
		GraphNode n;
		Set<String> intersect;
		GraphNode nodeFrom;
		GraphEdge edge;

		while (!queue.isEmpty()) {
			// Poll next from queue
			sConn = queue.poll();

			if (!visited.contains(sConn.id)) {
				visited.add(sConn.id);

				// Retrieve graph node (adds node to graph if not already there)
				nodeTo = _getGraphNode(sConn.id, graph);
				sInput = new HashSet<String>(sConn.s.input);

				// While all of its inputs haven't been matched
				while (!sInput.isEmpty()) {
					// Pick next most relevant service
					n = _pickNextNode(sConn, graph, dimensions);
					if (n == null || n.id == sConn.id)
						return null;
					else if (n.id == END_IDX || n.id == NULL_IDX)
						continue;
					// Ensure service is not End, Null, or is itself
					else {
						// Check if its output feeds the input of the service we
						// want to connect
						intersect = _doIntersection(sInput,
								n.s.output);
						/*
						 * If it does, remove output that is fed from list of
						 * needed inputs, /* add connection to particle, and add
						 * service to queue (if it is not the /* start service)
						 */
						if (!intersect.isEmpty()) {
							sInput.removeAll(intersect);

							// Create graph connections here
							nodeFrom = _getGraphNode(n.id, graph);
							edge = new GraphEdge(intersect, edgeIdx);
							graph.edgeMap.put(edgeIdx++, edge);
							edge.to = nodeTo;
							edge.from = nodeFrom;
							nodeTo.from.add(edge);
							nodeFrom.output.addAll(intersect);
							nodeFrom.to.add(edge);
							nodeTo.input.addAll(intersect);

							// Put service in queue if it has not already been
							// visited
							if (n.id != START_IDX && !visited.contains(n.id)) {
								queue.offer(n);
							}
						}
					}
				}
			}
		}
		return graph;
	}

	/**
	 * Selects the next node to be incorporated into a workflow. The choice is
	 * made based on which node has the highest score based on the arguments
	 * provided.
	 *
	 * @param node - current node
	 * @param masterGraph
	 * @param dimensions - array containing score.
	 * @return chosen node
	 */
	private GraphNode _pickNextNode(GraphNode node, Graph<Integer> graph, float[] dimensions) {
		PriorityQueue<GraphEdge> queue = new PriorityQueue<GraphEdge>();

		for (GraphEdge e : node.from) {
			e.score = dimensions[e.id];
			queue.offer(e);
		}

		GraphEdge chosenEdge = queue.poll();
		GraphNode chosenNode = new GraphNode(chosenEdge.from);

		GraphNode origin = graph.nodeMap.get(node.id);
		if (origin == null) {
			System.err.println("Origin node should not be null.");
			System.exit(1);
		}
		GraphNode destination = graph.nodeMap.get(chosenNode.id);

		// Check for cycles

		while (destination != null && chosenEdge != null && _hasPath(origin, destination)) {
			chosenEdge = queue.poll();
			chosenNode = new GraphNode(chosenEdge.from);
			// Update the destination
			destination = graph.nodeMap.get(chosenNode.id);
		}

		node.from.remove(chosenEdge);

		return chosenNode;
	}

	/**
	 * Checks whether there is a path between two graph nodes
	 * in a DAG, using a basic depth-first traversal.
	 *
	 * @param origin
	 * @param destination
	 * @return true if there is a path, false otherwise
	 */
	private boolean _hasPath(GraphNode origin, GraphNode destination) {
		/* The end service in the graph is never the origin of any edges,
		 * and the start service is never the destination.*/
		if (origin.id == END_IDX || destination.id == START_IDX)
			return false;

		Queue<GraphNode> queue = new LinkedList<GraphNode>();
		queue.offer(origin);

		while(!queue.isEmpty()) {
			GraphNode current = queue.poll();
			if (current == destination)
				return true;
			else {
				for (GraphEdge e : current.to) {
					queue.offer(e.to);
				}
			}
		}
		return false;
	}

	/**
	 * Calculates the fitness of a candidate particle in the swarm.
	 *
	 * @param p
	 * @return fitness
	 */
	private Graph<Integer> _calculateFitness(Particle p) {
		Graph<Integer> workflow = _getWorkflow(p.dimensions);

		double A = 1.0;
		double R = 1.0;
		double C = 0.0;
		for (GraphNode n : workflow.nodeMap.values()) {
			if (n.id != START_IDX && n.id != END_IDX) {
				A *= n.s.availability;
				R *= n.s.reliability;
				C += n.s.cost;
			}
		}

		double T = _findLongestPath(workflow);

		// Normalise C and T (values between [0,1]) using the sums of all values
		// from services
		// that could be possibly in the composition.
		C = C / _totalCost;
		T = T / _totalTime;

		// p.fitness = (W1 * A + W2 * R) / (W3 * T + W4 * C);
		p.fitness = (W1 * A + W2 * R + W3 * (1 - T) + W4 * (1 - C));
		return workflow;
	}

	/**
	 * Calculates the intersection of two sets without destroying the original
	 * sets.
	 *
	 * @param a
	 * @param b
	 * @return intersection
	 */
	private Set<String> _doIntersection(Set<String> a, Set<String> b) {
		Set<String> intersection = new HashSet<String>(a);
		intersection.retainAll(b);
		return intersection;
	}

	/**
	 * Updates the velocity vector of a particle.
	 *
	 * @param p
	 */
	private void _updateVelocity(Particle p) {
		float[] vel = p.velocity;
		float[] dim = p.dimensions;
		float[] bestDim = p.bestDimensions;
		float[] globalBestDim = Particle.globalBestDimensions;

		for (int i = 0; i < vel.length; i++) {
			vel[i] = (W * vel[i])
					+ (C1 * _random.nextFloat() * (bestDim[i] - dim[i]))
					+ (C2 * _random.nextFloat() * (globalBestDim[i] - dim[i]));
		}
	}

	/**
	 * Updates the position (i.e. dimension vector) of a particle.
	 *
	 * @param p
	 */
	private void _updatePosition(Particle p) {
		float newValue;
		for (int i = 0; i < numDimensions; i++) {
			// Calculate new position for that dimension
			newValue = p.dimensions[i] + p.velocity[i];
			// Ensure new position is within bounds
			if (newValue < 0.0)
				newValue = 0.0f;
			else if (newValue > 1.0)
				newValue = 1.0f;
			// Update dimension array with new value
			p.dimensions[i] = newValue;
		}
	}
}