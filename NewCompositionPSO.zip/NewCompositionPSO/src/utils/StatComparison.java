package utils;

import gp.QoSModel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.math.stat.descriptive.moment.Mean;
import org.apache.commons.math.stat.descriptive.moment.StandardDeviation;
import org.epochx.gp.wsc.ServiceComposition;

import pso.NewCompositionPSO;
import pso.OldCompositionPSO;
import pso.OldParticle;
import pso.OldService;
import pso.Particle;
import pso.Service;

/**
 * A small program for statistically comparing
 * the performance of two programs that use
 * the same dataset, same fitness function and
 * composition tasks. The values are read from
 * execution logs.
 *
 * @author sawczualex
 *
 */
public class StatComparison {
	public static final boolean IS_GP = true; // XXX Flip the switch
	public static final boolean CONSIDER_SETUP_TIME = false;
	public static final String ANALYSIS_LOG_PREFIX = "statComparison";
	public static final String LOG1_PREFIX = "pso";
	public static String LOG2_PREFIX;
	public static final String STAT_LOG1_PREFIX = "psoStats";
	public static String STAT_LOG2_PREFIX;

	public static final String[] FILE_LIST = {"dataset1.txt",
											  "dataset2.txt",
											  "dataset3.txt",
											  "dataset4.txt",
											  "dataset5.txt",
											  "bigDataset5.txt"
											  //"pathDataset1.txt",
											  //"pathDataset2.txt",
											  //"pathDataset3.txt",
											  //"pathDataset4.txt",
											  //"pathDataset5.txt",
											  //"pathBigDataset5.txt",
										      //"bigComposition1.txt",
											  //"bigComposition2.txt",
											  //"bigComposition3.txt",
											  //"bigComposition4.txt"
											  };

	public static final String[][] INPUT_LIST = {{"PhoneNumber"},
												 {"ZipCode", "Date"},
												 {"From", "To", "DepartDate", "ReturnDate"},
												 {"From", "To", "DepartDate", "ReturnDate"},
												 {"From", "To", "DepartDate", "ReturnDate"},
												 {"From", "To", "DepartDate", "ReturnDate"}
												   //{"PhoneNumber"},
												   //{"ZipCode", "Date"},
												   //{"From", "To", "DepartDate", "ReturnDate"},
												   //{"From", "To", "DepartDate", "ReturnDate"},
												   //{"From", "To", "DepartDate", "ReturnDate"},
												   //{"From", "To", "DepartDate", "ReturnDate"},
												   //{"input0"},
												   //{"input0"},
												   //{"input0"},
												   //{"input0"}
												   };
	public static final String[][] OUTPUT_LIST = {{"Address"},
												  {"City", "WeatherInfo"},
												  {"ArrivalDate", "Reservation"},
												  {"ArrivalDate", "Reservation", "BusTicket", "Map"},
												  {"ArrivalDate", "Reservation", "BusTicket", "Map"},
												  {"ArrivalDate", "Reservation", "BusTicket", "Map"}
												    //{"Address"},
												    //{"City", "WeatherInfo"},
												    //{"ArrivalDate", "Reservation"},
												    //{"ArrivalDate", "Reservation", "BusTicket", "Map"},
												    //{"ArrivalDate", "Reservation", "BusTicket", "Map"},
												   //{"ArrivalDate", "Reservation", "BusTicket", "Map"},
											        //{"output8", "output7", "output6", "output10", "output9"},
												    //{"output18", "output19", "output20", "output16", "output17"},
												    //{"output26", "output28", "output27", "output30", "output29"},
													//{"output39", "output38", "output37", "output36", "output40"}
												  };
	public static final int NUM_RUNS = 50;

	public static void main(String[] main) {
		if (IS_GP) {
			LOG2_PREFIX = "gp";
			STAT_LOG2_PREFIX = "gpStats";
		}
		else {
			LOG2_PREFIX = "oldPso";
			STAT_LOG2_PREFIX = "oldPsoStats";
		}

		for (int j = 0; j < FILE_LIST.length; j++) {
			System.out.printf("Testing with file '%s'...", FILE_LIST[j]);
			String dateTime = new SimpleDateFormat("_dd-MM-yyyy_HH-mm-ss").format(Calendar.getInstance().getTime());

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}

			new NewCompositionPSO(LOG1_PREFIX + dateTime, STAT_LOG1_PREFIX + dateTime, FILE_LIST[j], INPUT_LIST[j], OUTPUT_LIST[j]);
			if (IS_GP)
				new QoSModel(LOG2_PREFIX + dateTime, STAT_LOG2_PREFIX + dateTime, FILE_LIST[j], INPUT_LIST[j], OUTPUT_LIST[j]);
			else
				new OldCompositionPSO(LOG2_PREFIX + dateTime, STAT_LOG2_PREFIX + dateTime, FILE_LIST[j], INPUT_LIST[j], OUTPUT_LIST[j]);

			try {
				double[] time1 = new double[NUM_RUNS];
				double[] time2 = new double[NUM_RUNS];
				Pattern timePattern = Pattern.compile("time\\[(\\d+)\\]");
				Pattern fitnessPattern = Pattern.compile("([0-9]+.[0-9]+)");
				double setupTime1 = 0.0;
				double setupTime2 = 0.0;

				double[] fitness1 = new double[NUM_RUNS];
				double[] fitness2 = new double[NUM_RUNS];

				Scanner scan = new Scanner(new File(LOG1_PREFIX + dateTime + ".txt"));

				while(scan.hasNext("SETUP")) {
					String line = scan.nextLine();

					if (line.contains("SetupTime")) {
						Matcher m = timePattern.matcher(line);
						m.find();
						setupTime1 = Double.valueOf(m.group(1));
					}
				}

				int timeIdx = 0;
				int fitnessIdx = 0;
				while(scan.hasNext("RUN") || scan.hasNext("DETAILS")) {
					if (scan.hasNext("DETAILS")) {
						scan.nextLine();
						continue;
					}
					String line = scan.nextLine();

					if (line.contains("RunTime")) {
						Matcher m = timePattern.matcher(line);
						m.find();
						double time = Double.valueOf(m.group(1));
						if (CONSIDER_SETUP_TIME)
							time1[timeIdx++] = time + setupTime1;
						else
							time1[timeIdx++] = time;
					}
					else if (line.contains("GlobalBestFitness")) {
						Matcher m = fitnessPattern.matcher(line);
						m.find();
						String s = m.group(1);
						double fitness = Double.valueOf(m.group(1));
						fitness1[fitnessIdx++] = fitness;
					}
				}

				scan.close();

				scan = new Scanner(new File(LOG2_PREFIX + dateTime + ".txt"));

				while(scan.hasNext("SETUP")) {
					String line = scan.nextLine();

					if (line.contains("SetupTime")) {
						Matcher m = timePattern.matcher(line);
						m.find();
						setupTime2 = Double.valueOf(m.group(1));
					}
				}

				timeIdx = 0;
				fitnessIdx = 0;
				while(scan.hasNext("RUN") || scan.hasNext("DETAILS")) {
					if (scan.hasNext("DETAILS")) {
						scan.nextLine();
						continue;
					}

					String line = scan.nextLine();

					if (line.contains("RunTime")) {
 						Matcher m = timePattern.matcher(line);
						m.find();
						double time = Double.valueOf(m.group(1));
						if (CONSIDER_SETUP_TIME)
							time2[timeIdx++] = time + setupTime2;
						else
							time2[timeIdx++] = time;
					}
				     else if (line.contains("BestFitness") && !line.contains("NewBestFitness")) {
						Matcher m = fitnessPattern.matcher(line);
						m.find();
						double fitness = Double.valueOf(m.group(1));
						if (IS_GP)
							fitness2[fitnessIdx++] = 1 - fitness;
						else
							fitness2[fitnessIdx++] = fitness;

					}
				}
				scan.close();

				FileWriter writer = new FileWriter(new File(ANALYSIS_LOG_PREFIX + dateTime + ".htm"));
				writer.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\"><html><head /><body>\n");

				// Write first file
				writer.append(String.format("<h2>Log file: %s</h2>\n", LOG1_PREFIX + dateTime + ".txt"));
				writer.append("<table border=\"1\"><tr><th>Run</th><th>Time</th><th>Fitness</th></tr>\n");
				for(int i = 0; i < NUM_RUNS; i++) {
					writer.append(String.format("<tr><td>%d</td><td>%f</td><td>%f</td></tr>\n", i, time1[i], fitness1[i]));
				}
				writer.append("</table>");

				scan = new Scanner(new File(STAT_LOG1_PREFIX + dateTime + ".txt"));
				writer.append("<p>\n");
				while(scan.hasNext("SETUP")) {
					String line = scan.nextLine();
					if (!line.contains("BestDimensions"))
						writer.append(line + "<br>\n");
				}

				while(scan.hasNext("POSTRUN")) {
					String line = scan.nextLine();
					if (!line.contains("BestDimensions"))
						writer.append(line + "<br>\n");
				}
				writer.append("</p>\n");

				// Throw away first two lines

				while(scan.hasNext("Performance") || scan.hasNext("Tag")) {
					scan.nextLine();
				}

				writer.append("<table border=\"1\"><tr><th>Avg(ms)</th><th>Min</th><th>Max</th><th>Std Dev</th><th>Count</th></tr>\n");
				// Throw away next token
				scan.next();
				writer.append(String.format("<tr><td>%f</td><td>%d</td><td>%d</td><td>%f</td><td>%d</td></tr></table>\n",
						scan.nextDouble(), scan.nextLong(), scan.nextLong(), scan.nextDouble(), scan.nextInt()));
				scan.close();

				// Write second
				writer.append(String.format("<h2>Log file: %s</h2>\n", LOG2_PREFIX + dateTime + ".txt"));
				writer.append("<table border=\"1\"><tr><th>Run</th><th>Time</th><th>Fitness</th></tr>\n");
				for(int i = 0; i < NUM_RUNS; i++) {
					writer.append(String.format("<tr><td>%d</td><td>%f</td><td>%f</td></tr>\n", i, time2[i], fitness2[i]));
				}
				writer.append("</table>");

				scan.close();

				scan = new Scanner(new File(STAT_LOG2_PREFIX + dateTime + ".txt"));
				writer.append("<p>\n");
				while(scan.hasNext("SETUP")) {
					String line = scan.nextLine();
					if (!line.contains("BestDimensions"))
						writer.append(line + "<br>\n");
				}

				while(scan.hasNext("POSTRUN")) {
					String line = scan.nextLine();
					writer.append(line + "<br>\n");
				}
				writer.append("</p>\n");

				// Throw away first two lines (the lines with headers)
				while(scan.hasNext("Performance") || scan.hasNext("Tag"))
					scan.nextLine();

				writer.append("<table border=\"1\"><tr><th>Avg(ms)</th><th>Min</th><th>Max</th><th>Std Dev</th><th>Count</th></tr>\n");
				// Throw away next token
				if (scan.hasNext("RunTime"))
					scan.next();
				writer.append(String.format("<tr><td>%f</td><td>%d</td><td>%d</td><td>%f</td><td>%d</td></tr></table>\n",
						scan.nextDouble(), scan.nextLong(), scan.nextLong(), scan.nextDouble(), scan.nextInt()));
				scan.close();

				writer.append(String.format("<p>Average fitness 1: %f , Standard deviation 1: %f<br>\n", new Mean().evaluate(fitness1), new StandardDeviation().evaluate(fitness1)));
				writer.append(String.format("Average fitness 2: %f , Standard deviation 2: %f</p>\n", new Mean().evaluate(fitness2), new StandardDeviation().evaluate(fitness2)));
				// Turn arrays negatives for tests
				for (int i = 0; i < NUM_RUNS; i++) {
					time1[i] = -time1[i];
					time2[i] = -time2[i];
				}

				writer.append("<h2>Wilcoxon Test (95%): Mine</h2>\n");
				writer.append(String.format("<p>Time test: %s<br>\n", WilsonTestBing.TestBingNew(time2, time1)));
				writer.append(String.format("Fitness test: %s</p>\n", WilsonTestBing.TestBingNew(fitness2, fitness1)));

				writer.append("<h2>Wilcoxon Test (95%): Theirs</h2>\n");
				writer.append(String.format("<p>Time test: %s<br>\n", WilsonTestBing.TestBingNew(time1, time2)));
				writer.append(String.format("Fitness test: %s</p>\n", WilsonTestBing.TestBingNew(fitness1, fitness2)));

				writer.append("<p><strong>NOTE:</strong> a minus sign means that the approach cannot be proven statistically better by using this test.</p>");

				writer.append("</body></html>");
				writer.close();

				System.out.println("...Done.");

			}
			catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("All done!");
	}
}
