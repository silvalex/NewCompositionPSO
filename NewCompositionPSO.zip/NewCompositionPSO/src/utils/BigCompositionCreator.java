package utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import pso.Service;

/**
 * A small program for creating datasets that can form
 * compositions with high numbers of services. This is
 * accomplished by creating compositions that have rows,
 * and each row is fully connected to the next. Multiple
 * possible composition tasks may be created in each file.
 *
 * @author sawczualex
 */
public class BigCompositionCreator {
	// Controls number of rows in composition
	public static final int ROWS = 10;
	// Controls the number of services in each row
	public static final int SERV_PER_ROW = 4;
	// Controls number of replicas a service has
	// (i.e. same input/output, different QoS)
	public static final int REPLICA_SERVS = 400;
	// Controls number of possible compositions
	public static final int TOTAL_COMPS = 1;
	public static final String outputFile = "bigCompositionTestBlah.txt";
	public static final String taskOutputFile = "bigCompositionTest-task40-h.txt";
	public static final List<String> newLines = new ArrayList<String>();

	public static final void main(String[] args) {
		try {
			int ioCount = 0;
			FileWriter taskWriter = new FileWriter(new File(taskOutputFile));
			Random rand = new Random();

			Set<String> currOutput = new HashSet<String>();
			Set<String> prevOutput = new HashSet<String>();

			for (int g = 0; g < TOTAL_COMPS; g++) {
				int servCount = 0;
				prevOutput.add("input" + ioCount++);
				taskWriter.append(String.format("========== Task %d ==========\n", g + 1));
				taskWriter.append("Task input: " + prevOutput + "\n");
				for (int h = 0; h < ROWS; h++) {
					String[] input = new String[prevOutput.size()];
					input = prevOutput.toArray(input);

					for (int i = 0; i < SERV_PER_ROW; i++) {
						String[] output;
						if (h == ROWS-1)
							output = new String[]{"output" + ioCount++};
						else
							output = new String[]{"io" + ioCount++};

						currOutput.addAll(Arrays.asList(output));

						Service s = new Service(servCount, String.format("serv%d-%d-%d", g, h, servCount++), rand.nextInt(1001), rand.nextInt(1001),
								rand.nextInt(101), rand.nextInt(101), input, output);

						newLines.add(s.toFileString() + "\n");

						// Write copies
						String originalName = s.name;
						for (int j = 0; j < REPLICA_SERVS; j++) {
							s.name = originalName + "-" + j;
							// Make QoS progressively worse
							s.time += 5;
							s.cost += 5;
							s.availability -= 3.0;
							if (s.availability <= 0.0)
								s.availability = 0.0;
							s.reliability -= 3.0;
							if (s.reliability <= 0.0)
								s.reliability = 0.0;

							newLines.add(s.toFileString() + "\n");
						}
					}
					prevOutput = new HashSet<String>(currOutput);
					currOutput.clear();
				}
				taskWriter.append("Task output: " + prevOutput + "\n");
				taskWriter.append("Number of services required: " + ROWS * SERV_PER_ROW + "\n");
				prevOutput.clear();
			}
			taskWriter.close();

			Collections.shuffle(newLines);
			FileWriter writer = new FileWriter(new File(outputFile));
			for (String line: newLines)
				writer.append(line);
			writer.close();
			System.out.println("Big composition file done!");
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
