package utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import pso.Service;

/**
 * Normalizes files to be compatible with Yang's program.
 *
 * @author sawczualex
 */
public class FileNormalizer {
	public static void main(String[] args) {
		try {
			String filename = "bigDataset5.txt";
			String normalisedFileName = "bigDataset5-normalised.txt";

			// Read in original file
			List<Service> serviceList = new ArrayList<Service>();
			Scanner scan;
			scan = new Scanner(new File(filename));

			int id = 0;
			while (scan.hasNext())
				serviceList.add(id, new Service(id++, scan));
			scan.close();

			// Normalise and write to new file
			FileWriter writer = new FileWriter(new File(normalisedFileName));
			for (Service s: serviceList) {
				s.normalizeAttributes();
				writer.append(s.toFileStringNoPadding() + "\n");
			}
			writer.close();
			System.out.println("Done!");
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
