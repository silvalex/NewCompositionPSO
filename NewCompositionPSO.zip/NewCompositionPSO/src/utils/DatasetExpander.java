package utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import pso.Service;

/**
 * A small program for increasing the size
 * of a dataset by creating n copies of each
 * service, with steadily decreasing QoS values.
 *
 * @author sawczualex
 *
 */
public class DatasetExpander {
	public static final int N = 9;
	public static final String inputFile = "dataset5.txt";
	public static final String outputFile = "bigDataset5.txt";
	public static final List<String> newLines = new ArrayList<String>();

	public static final void main(String[] args) {
		try {
			Scanner scan = new Scanner(new File(inputFile));
			while(scan.hasNext()) {
				Service s = new Service(0, scan);
				// Write original
				newLines.add(s.toFileString() + "\n");
				// Write copies
				String originalName = s.name;
				for (int i = 0; i < N; i++) {
					s.name = originalName + i;
					// Make QoS progressively worse
					s.time += 5;
					s.cost += 5;
					s.availability -= 3.0;
					if (s.availability <= 0.0)
						s.availability = 0.0;
					s.reliability -= 3.0;
					if (s.reliability <= 0.0)
						s.reliability = 0.0;

					newLines.add(s.toFileString() + "\n");
				}
			}
			scan.close();

			Collections.shuffle(newLines);
			FileWriter writer = new FileWriter(new File(outputFile));
			for (String line: newLines)
				writer.append(line);
			writer.close();
			System.out.println("Expansion done!");
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
