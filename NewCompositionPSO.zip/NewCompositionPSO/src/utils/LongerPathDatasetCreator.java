package utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import pso.Service;

/**
 * A small program that creates two services for each
 * existing service, which combined will result in better
 * QoS values than the original service.
 *
 * @author sawczualex
 */
public class LongerPathDatasetCreator {
	public static final int N = 2;
	public static final double TIME_FACTOR = 0.9;
	public static final double COST_FACTOR = 0.9;
	public static final double RELIA_FACTOR = 1.1;
	public static final double AVAILA_FACTOR = 1.1;
	public static final double MAX_RELIA = 100.0;
	public static final double MAX_AVAIL = 100.0;
	public static final String PREFIX = "xyz"; // Prefix for creating fake input/output parameters
	public static final String inputFile = "bigDataset5.txt";
	public static final String outputFile = "pathBigDataset5.txt";
	public static final List<String> newLines = new ArrayList<String>();

	public static final void main(String[] args) {
		try {
			int suffix = 0;
			Scanner scan = new Scanner(new File(inputFile));
			while(scan.hasNext()) {
				Service s = new Service(0, scan);
				// Write original
				newLines.add(s.toFileString() + "\n");

				// Generate better Qos, with lower overall time/cost
				// and higher reliability/availability
				double time = (s.time/N) * TIME_FACTOR;
				double cost = (s.cost/N) * COST_FACTOR;
				double initialRelia = s.reliability * RELIA_FACTOR;
				if (initialRelia > MAX_RELIA)
					initialRelia = MAX_RELIA;
				double initialAvail = s.availability * AVAILA_FACTOR;
				if (initialAvail > MAX_AVAIL)
					initialAvail = MAX_AVAIL;

				// Write copies to file
				for (int i = 0; i < N; i++) {
					String[] input = {PREFIX + suffix++};
					String[] output = {PREFIX + suffix};
					double reliability = MAX_RELIA;
					double availability = MAX_AVAIL;
					// If creating first service, make it compatible with original input
					if (i == 0) {
						input = s.input.toArray(new String[0]);
						// Adjust reliability and availability
						reliability = initialRelia;
						availability = initialAvail;
					}
					// If creating last service, make it compatible with original output
					if (i == N-1)
						output = s.output.toArray(new String[0]);


					Service copy = new Service(0, s.name + i, time, cost, availability, reliability, input, output);
					newLines.add(copy.toFileString() + "\n");
				}
			}
			scan.close();

			Collections.shuffle(newLines);
			FileWriter writer = new FileWriter(new File(outputFile));
			for (String line: newLines)
				writer.append(line);
			writer.close();
			System.out.println("Path creation done!");
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
